:star: Please star this project. It helps a lot.
# RiceMillManagementSystemWebsite

![](.//media/Capture1.PNG?raw=true)
![](.//media/Capture2.PNG?raw=true)
![](.//media/Capture3.PNG?raw=true)
![](.//media/Capture4.PNG?raw=true)
![](.//media/Capture5.PNG?raw=true)
![](.//media/Capture6.PNG?raw=true)
![](.//media/Capture7.PNG?raw=true)
![](.//media/Capture8.PNG?raw=true)
![](.//media/Capture9.PNG?raw=true)
![](.//media/Capture10.PNG?raw=true)
![](.//media/Capture11.PNG?raw=true)
![](.//media/Capture12.PNG?raw=true)
![](.//media/Capture13.PNG?raw=true)
![](.//media/Capture14.PNG?raw=true)
![](.//media/Capture15.PNG?raw=true)
